package Practiceproject;

import java.util.regex.*;    
import java.util.*;  

public class emailvalidation {
	 public static void main(String args[]){  
		 
	        ArrayList<String> email = new ArrayList<String>();  
	        email.add("jameel@gmail.co.in");  
	        email.add("sanjay^gmail.com");  
	        email.add("ahmed@gmail.com");  
	        email.add("jameel@gmailcom"); 
	        email.add("Jam089@gmail.com");
	        //Add invalid email in list    
	        email.add("johnson$gmail.com");  
	        //Regular Expression   
	        String regex = "^[A-Za-z0-9+_.-]+@(.+)$";  
	        //Compile regular expression to get the pattern  
	        Pattern pattern = Pattern.compile(regex);  
	        //Iterate email array list  
	        for(String eemail : email){  
	            //Create instance of matcher   
	            Matcher matcher = pattern.matcher(eemail);  
	            System.out.println(eemail +" : "+ matcher.matches()+"\n");  
	        }  
	    }  
}
