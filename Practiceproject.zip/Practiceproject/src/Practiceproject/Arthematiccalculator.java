package Practiceproject;

import java.util.Scanner;

public class Arthematiccalculator {
		public static void main(String args[]) {
			
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Select the type of operation ");
			System.out.println(" 1Addition \n 2-Subratction \n 3-Multiplication \n 4-DivisIon");
			
			System.out.println("Select the option:");
			int option = sc.nextInt();
			System.out.println("Enter the fisrt value");
			int a= sc.nextInt();
			System.out.println("Enter the second value");
			int b= sc.nextInt();
			
			
			if(option ==1) {
				System.out.println("Addition value is " + (a+b));
			}
			else if(option == 2) {
				System.out.println("Subtraction value is "+ (a-b));
			}
			else if(option == 3) {
				System.out.println("Multilplication value is "+(a*b));
			}
			else if(option == 4){
				try {
					System.out.println("Division value is" + (double)(a/b));
				} 
				catch(Exception rf)
					{
					System.out.println("Enter the correct second value");
				}
					}
				else {
					System.out.println("Select the  correct option");
				}
				
		}}




