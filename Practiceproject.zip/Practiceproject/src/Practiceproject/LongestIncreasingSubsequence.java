package Practiceproject;
import java.util.ArrayList;
import java.util.Iterator;

public class LongestIncreasingSubsequence {
	public static void main(String[] args) {
		 int array[] = {2,18,25,64,88,54,94,23};
		 ArrayList list = new ArrayList();
		 ArrayList longestIncreasingList = new ArrayList();
		 int Max;
		 int length = 0;
		 for(int i = 0; i < array.length;i++)
		 {
		 Max = Integer.MIN_VALUE;
		 for(int j = i;j < array.length; j++)
		 {
		 if(array[j] > Max)
		 {
		 list.add(array[j]);
		 Max = array[j];
		 }
		 }

		 if(length< list.size())
		 {
		 length= list.size();
		 longestIncreasingList = new ArrayList(list);
		 }
		 list.clear();
		 }
		 System.out.println();
		 Iterator itr = longestIncreasingList.iterator();
		 System.out.println("The Longest subsequence");
		 while(itr.hasNext())
		 {
		 System.out.print(itr.next() + " ");
		 }
		 System.out.println();
		 System.out.println("Length of LIS: " +length);
		 }

		}
	


