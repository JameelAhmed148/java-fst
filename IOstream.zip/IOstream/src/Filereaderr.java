import java.io.*;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class Filereaderr {
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the file name");
		
		FileInputStream fi=new FileInputStream(sc.next());
		if(fi!=null) {
			System.out.println("file exists");
		}
		int i=0;
		//-1 is EOF
		while((i=fi.read())!=-1){
			System.out.print((char)i);
		}
	


}}
