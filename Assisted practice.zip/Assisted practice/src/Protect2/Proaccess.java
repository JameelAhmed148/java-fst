package Protect2;
import Protect1.*;

public class Proaccess extends Protectedaccess {
	
	public static void main(String[] args) {
		Protectedaccess obj = new  Protectedaccess();   
	       obj.display();  
	}


	

}
