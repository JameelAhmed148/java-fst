package Public1;


public class Publicaccess {
	public void display() 
    { 
        System.out.println("This is Public Access Specifiers"); 
    } 


}
