package Public2;
import Public1.*;

public class Publicacc extends Publicaccess {
public static void main(String[] args) {
		
		Publicaccess obj = new Publicaccess(); 
        obj.display();  
		
	}
}

	


