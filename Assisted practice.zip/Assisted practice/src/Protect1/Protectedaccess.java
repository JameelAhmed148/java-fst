package Protect1;


public class Protectedaccess {
	public void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 
}



