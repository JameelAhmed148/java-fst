package Accessmodiifiers;

class Defaccess
{ 
  void display() 
     { 
         System.out.println("success"); 
     } 
} 

public class Defaultmodifier {
	public static void main(String[] args) {
		//default
		System.out.println("This is Default Access Specifier");
		Defaccess defult = new Defaccess(); 		  
        defult.display(); 

	}


}
