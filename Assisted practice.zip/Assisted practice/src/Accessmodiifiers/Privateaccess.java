package Accessmodiifiers;

class Privateacc
{ 
   void display() 
    { 
        System.out.println("SUCCESS"); 
    } 
} 


public class Privateaccess {
	public static void main(String[] args) {
		//private
		System.out.println("This is Private Access Specifier");
		Privateacc  obj = new Privateacc(); 
        //trying to access private method of another class 
        obj.display();

	}

	

}
