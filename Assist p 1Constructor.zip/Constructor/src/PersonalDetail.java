//defult const
public class PersonalDetail {

	PersonalDetail() {
		int salary = 50000,bonus = 5000;
		System.out.println("final amount is :" +(bonus+salary));
	}


}
