//parameterized constructor
public class Person {
	public static void main(String[] args) {
		PersonalDetails persondetail=new PersonalDetails(50000,5000);
		
	}



}
