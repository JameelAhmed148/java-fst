//parameterized constructor
public class PersonalDetails {
	PersonalDetails(int salary, int bonus) {
		System.out.println("final amount is :" +(bonus+salary));
	}

}
