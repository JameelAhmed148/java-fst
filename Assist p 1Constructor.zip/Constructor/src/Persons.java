//defult cont
public class Persons {
	public static void main(String[] args) {
		PersonalDetail persondetail=new PersonalDetail();
		
	}


}
